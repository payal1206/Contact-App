import React from "react";

const Footer = () => {
  return (
    <div>
      {" "}
      <h1>Footer here</h1>
    </div>
  );
};
export default Footer;
